-- MySQL dump 10.13  Distrib 8.0.43, for Linux (x86_64)
--
-- Host: localhost    Database: mersyar_bot_db
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_daily_notes`
--

DROP TABLE IF EXISTS `admin_daily_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_daily_notes` (
  `id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_daily_notes`
--

LOCK TABLES `admin_daily_notes` WRITE;
/*!40000 ALTER TABLE `admin_daily_notes` DISABLE KEYS */;
INSERT INTO `admin_daily_notes` VALUES ('27ea1200-66df-4185-9090-cc4b3204d04b','افزودن پنل دوم مرزبان','این امکان اضافه کردن دو یا چند پنل مرزبان به ربات','2025-09-25 06:13:35'),('2cb0fe9e-16ed-45dd-9082-2df8bfc394e3','X-ui','افزودن پنل x-ui','2025-09-25 06:12:09'),('2fc9ea2c-f5f4-48f0-8307-8066a01fc608','بسته شدن منو','منوی که باز است  دیگه نمیشه دوباره بازش کرد میخام بعد از یک دقیقه امکان دوباره منو باشه چه بسته شده بود چه نه','2025-10-05 16:29:52'),('6fb15772-4732-4e5e-8754-c2b3449ce733','تایید اتوماتیک','واریز بدونه تایید ادمین انجام شود','2025-09-26 12:44:40'),('8050f35f-0419-49c0-ba0e-5c55772cc74a','جاب روزانه پیام پایان حجم میده','اما در پیام دکمه افزایش حجم نیست','2025-10-05 16:31:07'),('a14fd690-bb9c-4fcf-bae3-8377d3f1874b','بعد از دریافت کانفیگ دکمه های کیبورد','بعد از دریافت کانفیگ دکمه های کیبورد محو نمیشه','2025-10-13 16:55:19'),('c6d9f18e-d232-4f9c-a4f6-f7f882481e34','مشخصات کاربر','مشخصات کاربر اضافه شود','2025-09-16 16:41:17'),('c9cc221d-dcf5-4c6e-9745-e17500466ff2','عدم وجود کیبورد بعد از ارسال دلخواه','هیج دکمه بازگشتی برای کاربر نیست','2025-10-19 14:20:47'),('cd6eabe5-f979-4e91-afa1-29145e8698e2','پیام خوش امد','دکمه ویرایش و اضافه کردن پیام خوش آمد','2025-09-20 05:37:49'),('d4cddf33-174b-4525-84c8-bb86c9d61913','حذف متن کنسل','متن کنسل حذف شود و دکمه بازگشت به کیبورد بزرگ اضافه شود','2025-10-14 10:05:24'),('d69611cc-a02a-4cdc-b3a2-10282e0317e5','گزارش به کانال','کانال گزارش تکمیل شود مانند اضافه شدن یوزر و آیدی کاریر','2025-09-17 07:55:12');
/*!40000 ALTER TABLE `admin_daily_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bot_managed_users`
--

DROP TABLE IF EXISTS `bot_managed_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bot_managed_users` (
  `marzban_username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`marzban_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bot_managed_users`
--

LOCK TABLES `bot_managed_users` WRITE;
/*!40000 ALTER TABLE `bot_managed_users` DISABLE KEYS */;
INSERT INTO `bot_managed_users` VALUES ('5rooz'),('aliasghar'),('asgharbiseda'),('ddddddeetest'),('douvood'),('gfggf'),('hasan02'),('hosein10'),('mdo1212'),('mees02'),('mees8'),('mers77'),('mihtessstm02'),('mmm05'),('mmmmmohhh9'),('mmmmo07'),('moh01'),('moh1122'),('mohades33'),('mohadeseh'),('mohatesal0223'),('mohtesss343'),('mohtesss66'),('mohtessst003'),('mohtesst'),('mohtest02'),('mtesssd7'),('mtt1212'),('narges03'),('navid02'),('nersss088'),('poshtttttt02'),('tessssty7'),('test_5877451098_a5w4'),('test_5877451098_nyrj'),('test_5877451098_yidy'),('test01test'),('tizhoosh'),('tttttootest'),('tttttttest'),('ytyyyyy'),('yyyyyyyhhtest');
/*!40000 ALTER TABLE `bot_managed_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bot_settings`
--

DROP TABLE IF EXISTS `bot_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bot_settings` (
  `setting_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bot_settings`
--

LOCK TABLES `bot_settings` WRITE;
/*!40000 ALTER TABLE `bot_settings` DISABLE KEYS */;
INSERT INTO `bot_settings` VALUES ('auto_delete_grace_days','5'),('forced_join_channel','mersvpn'),('is_auto_delete_enabled','False'),('is_forced_join_active','False'),('is_log_channel_enabled','False'),('is_maintenance_mode','False'),('is_test_account_enabled','True'),('is_wallet_enabled','False'),('log_channel_id','-1002103623736'),('reminder_data_gb','1'),('reminder_days','2'),('reminder_time','21:01'),('test_account_gb','0.5'),('test_account_hours','12.0'),('test_account_limit','1'),('unlimited_plan_button_text','2️⃣ اشتراک نامحدود (با محدودیت کاربر)'),('volumetric_plan_button_text','♻️ پلن با حجم دلخواه'),('wallet_predefined_amounts','[25000, 50000, 75000, 100000, 150000, 200000, 500000]'),('welcome_gift_amount','30000');
/*!40000 ALTER TABLE `bot_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `broadcasts`
--

DROP TABLE IF EXISTS `broadcasts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `broadcasts` (
  `job_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `photo_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `buttons` json DEFAULT NULL,
  `target_user_ids` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `broadcasts`
--

LOCK TABLES `broadcasts` WRITE;
/*!40000 ALTER TABLE `broadcasts` DISABLE KEYS */;
/*!40000 ALTER TABLE `broadcasts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `financial_settings`
--

DROP TABLE IF EXISTS `financial_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `financial_settings` (
  `id` int NOT NULL DEFAULT '1',
  `card_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_holder` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_per_gb` int DEFAULT NULL,
  `price_per_day` int DEFAULT NULL,
  `base_daily_price` int DEFAULT '1000',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financial_settings`
--

LOCK TABLES `financial_settings` WRITE;
/*!40000 ALTER TABLE `financial_settings` DISABLE KEYS */;
INSERT INTO `financial_settings` VALUES (1,'6221061052146992','فرشته خزایی',1650,1000,1000);
/*!40000 ALTER TABLE `financial_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guides`
--

DROP TABLE IF EXISTS `guides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guides` (
  `guide_key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `photo_file_id` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `buttons` json DEFAULT NULL,
  PRIMARY KEY (`guide_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guides`
--

LOCK TABLES `guides` WRITE;
/*!40000 ALTER TABLE `guides` DISABLE KEYS */;
INSERT INTO `guides` VALUES ('android','اتصال اندروید','آموزش تصویری و ویدیوهای انتقال کانفیگ به v2rayng','AgACAgQAAxkBAAJAbWiywiknAsG_KpALbqaKTAUfxTL1AAL20TEbwBmZUUnFMgZhl5f0AQADAgADeQADNgQ','[{\"url\": \"https://t.me/mersvpn/224\", \"text\": \"آموزش ویدیوی\"}, {\"url\": \"https://github.com/2dust/v2rayNG/releases/download/1.10.8/v2rayNG_1.10.8_arm64-v8a.apk\", \"text\": \"دانلود V2RayNG\"}]'),('ios_guide','اتصال آیفون','📚 تنظیمات آموزش','AgACAgQAAxkBAAJA9GizCo1C-3P702bOEGRvbMRPQLCTAALe0jEbwBmZUQKr3rK3CgVaAQADAgADeAADNgQ','[{\"url\": \"https://t.me/mersvpn/299\", \"text\": \"آموزش ویدیویی\"}, {\"url\": \"https://apps.apple.com/us/app/streisand/id6450534064\", \"text\": \"دانلود Streisand\"}, {\"url\": \"https://telegra.ph/%D8%A2%D9%85%D9%88%D8%B2%D8%B4-%D8%AA%D8%B5%D9%88%DB%8C%D8%B1%DB%8C-%DA%A9%D8%A7%D8%B1-%D8%A8%D8%A7-%D9%86%D8%B1%D9%85%E2%80%8C%D8%A7%D9%81%D8%B2%D8%A7%D8%B1-Streisand-%D8%Aآ%DB%8C%D9%81%D9%88%D9%86-08-05\", \"text\": \"آموزش تصویری\"}]'),('windows_guide','اتصال به ویندوز','نحوه انتقال ساب و اتصال به v2ray n به زودی اضافه خواهد شد','AgACAgQAAxkBAAJBnmizSfX1p-CYIyBYBvATWdSzdjI3AALP4jEbwBmhURE1fB8s3EaZAQADAgADeQADNgQ','[{\"url\": \"https://github.com/2dust/v2rayN/releases\", \"text\": \"دانلود V2RAY N\"}]');
/*!40000 ALTER TABLE `guides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marzban_credentials`
--

DROP TABLE IF EXISTS `marzban_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marzban_credentials` (
  `id` int NOT NULL DEFAULT '1',
  `base_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marzban_credentials`
--

LOCK TABLES `marzban_credentials` WRITE;
/*!40000 ALTER TABLE `marzban_credentials` DISABLE KEYS */;
INSERT INTO `marzban_credentials` VALUES (1,'https://mehr.dorebaba.ir','dorsa','As88552200');
/*!40000 ALTER TABLE `marzban_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marzban_telegram_links`
--

DROP TABLE IF EXISTS `marzban_telegram_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marzban_telegram_links` (
  `marzban_username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `telegram_user_id` bigint NOT NULL,
  `auto_renew` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`marzban_username`),
  KEY `telegram_user_id_idx` (`telegram_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marzban_telegram_links`
--

LOCK TABLES `marzban_telegram_links` WRITE;
/*!40000 ALTER TABLE `marzban_telegram_links` DISABLE KEYS */;
INSERT INTO `marzban_telegram_links` VALUES ('9608639sara',6557190169,0),('abolfazl',76977825,0),('aliasghar',90111767,0),('alii5',954038397,0),('amirali',6548323566,0),('anahiita01',76977825,0),('asgharbiseda',6191287529,0),('ashe1',551043378,0),('ashkan02',76977825,1),('danial',76977825,0),('danial2',76977825,0),('dorsa',5877451098,1),('douvood',76977825,0),('farnaz',100912247,0),('fastvpn',150481212,1),('hasan02',5827504035,0),('hosein10',6191287529,0),('keshavarz',5827504035,1),('khoodadad02',6233097509,0),('leila65',5569979117,0),('lortabaran',8172420461,0),('mamad-ana2',5827504035,0),('mehdi',76977825,1),('mehrdad',6144847019,0),('mim',7913968242,0),('mohadeseh',99242966,1),('mohammad04',5604926986,0),('mohsen02',76977825,0),('narges03',76977825,0),('navid02',1183805914,0),('parisa',7606035924,0),('parisa02',76977825,0);
/*!40000 ALTER TABLE `marzban_telegram_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `non_renewal_users`
--

DROP TABLE IF EXISTS `non_renewal_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `non_renewal_users` (
  `marzban_username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`marzban_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `non_renewal_users`
--

LOCK TABLES `non_renewal_users` WRITE;
/*!40000 ALTER TABLE `non_renewal_users` DISABLE KEYS */;
INSERT INTO `non_renewal_users` VALUES ('moh01');
/*!40000 ALTER TABLE `non_renewal_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pending_invoices`
--

DROP TABLE IF EXISTS `pending_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pending_invoices` (
  `invoice_id` int NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `plan_details` json NOT NULL,
  `price` int NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `from_wallet_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`invoice_id`),
  KEY `user_id_idx` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=242 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pending_invoices`
--

LOCK TABLES `pending_invoices` WRITE;
/*!40000 ALTER TABLE `pending_invoices` DISABLE KEYS */;
INSERT INTO `pending_invoices` VALUES (1,150481212,'{\"price\": 60000, \"volume\": 15, \"duration\": 30}',60000,'rejected','2025-08-31 06:23:23',0.00),(2,150481212,'{\"price\": 60000, \"volume\": 15, \"duration\": 30}',60000,'rejected','2025-08-31 06:26:39',0.00),(3,150481212,'{\"price\": 60000, \"volume\": 15, \"duration\": 30}',60000,'approved','2025-08-31 06:34:59',0.00),(4,6680925972,'{\"price\": 70000, \"volume\": 20, \"duration\": 30}',70000,'approved','2025-08-31 07:55:26',0.00),(5,6680925972,'{\"price\": 90000, \"volume\": 30, \"duration\": 30, \"username\": \"moh01100\"}',90000,'approved','2025-08-31 08:11:53',0.00),(6,6680925972,'{\"price\": 90000, \"volume\": 30, \"duration\": 30, \"username\": \"moh01100\"}',90000,'approved','2025-08-31 08:13:03',0.00),(7,6680925972,'{\"price\": 91000, \"volume\": 30, \"duration\": 31, \"username\": \"moh01100\"}',91000,'approved','2025-08-31 08:22:04',0.00),(8,150481212,'{\"price\": 70000, \"volume\": 20, \"duration\": 30, \"username\": \"mohammad\"}',70000,'approved','2025-08-31 08:39:29',0.00),(9,150481212,'{\"price\": 85000, \"volume\": 30, \"duration\": 25, \"username\": \"mohammad\"}',85000,'approved','2025-08-31 08:44:59',0.00),(10,150481212,'{\"price\": 52000, \"volume\": 20, \"duration\": 12, \"username\": \"moham\"}',52000,'approved','2025-08-31 08:49:58',0.00),(11,150481212,'{\"price\": 84000, \"volume\": 30, \"duration\": 30, \"username\": \"moh1001\"}',84000,'approved','2025-08-31 09:16:34',0.00),(12,6680925972,'{\"price\": 41600, \"volume\": 12, \"duration\": 20, \"username\": \"mohkk\"}',41600,'rejected','2025-08-31 09:35:29',0.00),(13,150481212,'{\"volume\": 2, \"duration\": 1, \"username\": \"moh123\"}',5000,'approved','2025-08-31 23:14:41',0.00),(14,150481212,'{\"volume\": 1, \"duration\": 1, \"username\": \"moh431\"}',2000,'approved','2025-08-31 23:16:52',0.00),(15,150481212,'{\"volume\": 2, \"duration\": 1, \"username\": \"moh123\"}',5000,'approved','2025-08-31 23:29:55',0.00),(16,150481212,'{\"volume\": 1, \"duration\": 1, \"username\": \"mm321\"}',4000,'expired','2025-08-31 23:31:22',0.00),(17,150481212,'{\"volume\": 2, \"duration\": 1, \"username\": \"moh123\"}',5000,'approved','2025-08-31 23:40:15',0.00),(18,150481212,'{\"volume\": 2, \"duration\": 1, \"username\": \"moh123\"}',5000,'approved','2025-08-31 23:58:47',0.00),(19,150481212,'{\"volume\": 1, \"duration\": 1, \"username\": \"fer221\"}',6000,'approved','2025-09-01 00:00:40',0.00),(20,150481212,'{\"price\": 57000, \"volume\": 15, \"duration\": 30, \"username\": \"fer222\"}',57000,'expired','2025-09-01 00:01:55',0.00),(21,150481212,'{\"price\": 51000, \"volume\": 20, \"duration\": 15, \"username\": \"fer222\"}',51000,'expired','2025-09-01 00:27:19',0.00),(22,150481212,'{\"price\": 47000, \"volume\": 15, \"duration\": 20, \"username\": \"fer2221\"}',47000,'expired','2025-09-01 00:33:59',0.00),(23,150481212,'{\"price\": 47000, \"volume\": 15, \"duration\": 20, \"username\": \"fere01\"}',47000,'expired','2025-09-01 00:38:41',0.00),(24,150481212,'{\"price\": 47000, \"volume\": 15, \"duration\": 20, \"username\": \"feree02\"}',47000,'expired','2025-09-01 01:05:35',0.00),(25,150481212,'{\"price\": 35600, \"volume\": 12, \"duration\": 14, \"username\": \"fere03\"}',35600,'approved','2025-09-01 01:19:33',0.00),(26,150481212,'{\"volume\": 1, \"duration\": 1, \"username\": \"fereee022\"}',2000,'approved','2025-09-01 01:22:28',0.00),(27,150481212,'{\"price\": 53000, \"volume\": 15, \"duration\": 26, \"username\": \"fere011\"}',53000,'approved','2025-09-01 01:26:20',0.00),(28,150481212,'{\"volume\": 1, \"duration\": 2, \"username\": \"meri01\"}',4000,'approved','2025-09-01 01:27:50',0.00),(29,150481212,'{\"price\": 56000, \"volume\": 20, \"duration\": 20, \"username\": \"ferr001\"}',56000,'approved','2025-09-01 02:10:59',0.00),(30,150481212,'{\"price\": 66000, \"volume\": 20, \"duration\": 30, \"username\": \"fere01\"}',66000,'approved','2025-09-01 03:37:34',0.00),(31,150481212,'{\"volume\": 2, \"duration\": 2, \"username\": \"fere02\"}',5000,'approved','2025-09-01 03:39:37',0.00),(32,150481212,'{\"price\": 36600, \"volume\": 12, \"duration\": 15, \"username\": \"fere03\"}',36600,'approved','2025-09-01 03:53:53',0.00),(33,6680925972,'{\"price\": 28000, \"volume\": 10, \"duration\": 10, \"username\": \"mers01\"}',28000,'approved','2025-09-01 04:20:57',0.00),(34,150481212,'{\"price\": 79500, \"volume\": 30, \"duration\": 30, \"username\": \"moh01\"}',79500,'approved','2025-09-01 07:53:59',0.00),(35,150481212,'{\"price\": 109500, \"volume\": 30, \"duration\": 60, \"username\": \"moh02\"}',109500,'expired','2025-09-01 07:55:54',0.00),(36,150481212,'{\"price\": 89500, \"volume\": 30, \"duration\": 40, \"username\": \"moh03\"}',89500,'approved','2025-09-01 08:16:27',0.00),(37,6680925972,'{\"price\": 44750, \"volume\": 15, \"duration\": 20, \"username\": \"fere03\"}',44750,'approved','2025-09-01 16:49:07',0.00),(38,150481212,'{\"volume\": 1, \"duration\": 1, \"username\": \"moh01\"}',6300,'approved','2025-09-03 18:11:12',0.00),(39,6680925972,'{\"price\": 105000, \"volume\": 100, \"duration\": 15, \"username\": \"mers01\"}',105000,'approved','2025-09-05 03:29:59',0.00),(40,6680925972,'{\"volume\": 1, \"duration\": 2, \"username\": \"mees02\"}',3200,'approved','2025-09-05 03:32:32',0.00),(41,150481212,'{\"price\": 140000, \"volume\": 999, \"max_ips\": 1, \"plan_id\": 2, \"duration\": 30, \"username\": \"moe02\", \"plan_type\": \"unlimited\"}',140000,'approved','2025-09-05 03:34:53',0.00),(42,150481212,'{\"price\": 95000, \"volume\": 60, \"duration\": 30, \"username\": \"jhgffg\"}',95000,'expired','2025-09-05 03:38:47',0.00),(43,99242966,'{\"price\": 65000, \"volume\": 25, \"duration\": 30, \"username\": \"mohadeseh\"}',65000,'approved','2025-09-05 05:41:15',0.00),(44,99242966,'{\"price\": 130000, \"volume\": 120, \"duration\": 30, \"username\": \"hbsvsbbdb\"}',130000,'expired','2025-09-05 05:55:11',0.00),(45,6233097509,'{\"volume\": 100, \"duration\": 31, \"username\": \"douvood\"}',100000,'expired','2025-09-05 16:38:02',0.00),(46,6233097509,'{\"volume\": 100, \"duration\": 31, \"username\": \"douvood\"}',100000,'expired','2025-09-05 16:49:35',0.00),(47,150481212,'{\"price\": 30000, \"volume\": 12, \"duration\": 15, \"username\": \"moh01\"}',30000,'approved','2025-09-12 17:19:19',0.00),(48,150481212,'{\"price\": 100000, \"volume\": 30, \"duration\": 60, \"username\": \"hgggggg\"}',100000,'expired','2025-09-12 17:23:00',0.00),(49,150481212,'{\"price\": 27000, \"volume\": 20, \"username\": \"moh03\", \"plan_type\": \"data_top_up\"}',27000,'expired','2025-09-14 18:21:52',0.00),(50,150481212,'{\"volume\": 4, \"duration\": 5, \"username\": \"moh03\"}',2001,'approved','2025-09-14 18:25:52',0.00),(51,150481212,'{\"price\": 16200, \"volume\": 12, \"username\": \"moh03\", \"plan_type\": \"data_top_up\"}',16200,'approved','2025-09-14 18:36:34',0.00),(52,150481212,'{\"volume\": 4, \"duration\": 5, \"username\": \"moh03\"}',2001,'expired','2025-09-14 18:38:11',0.00),(53,5877451098,'{\"price\": 4050, \"volume\": 3, \"username\": \"dorsa\", \"plan_type\": \"data_top_up\"}',4050,'approved','2025-09-14 23:44:36',0.00),(54,5877451098,'{\"price\": 2700, \"volume\": 2, \"username\": \"dorsa\", \"plan_type\": \"data_top_up\"}',2700,'approved','2025-09-14 23:45:30',0.00),(55,150481212,'{\"price\": 140000, \"volume\": 999, \"max_ips\": 1, \"plan_id\": 2, \"duration\": 30, \"username\": \"nbbbvg\", \"plan_type\": \"unlimited\"}',140000,'approved','2025-09-15 08:02:32',0.00),(56,150481212,'{\"price\": 160000, \"volume\": 999, \"max_ips\": 2, \"plan_id\": 3, \"duration\": 30, \"username\": \"mohh02\", \"plan_type\": \"unlimited\"}',160000,'approved','2025-09-15 08:04:58',0.00),(57,150481212,'{\"price\": 45000, \"volume\": 10, \"duration\": 30, \"username\": \"mohh03\"}',45000,'approved','2025-09-15 08:06:15',0.00),(58,150481212,'{\"price\": 140000, \"volume\": 999, \"max_ips\": 1, \"plan_id\": 2, \"duration\": 30, \"username\": \"motess05\", \"plan_type\": \"unlimited\"}',140000,'approved','2025-09-15 17:01:48',0.00),(59,150481212,'{\"price\": 13500, \"volume\": 10, \"username\": \"mo01\", \"plan_type\": \"data_top_up\"}',13500,'approved','2025-09-16 05:57:10',0.00),(60,150481212,'{\"price\": 140000, \"volume\": 999, \"max_ips\": 1, \"plan_id\": 2, \"duration\": 30, \"username\": \"mohnnn08\", \"plan_type\": \"unlimited\"}',140000,'approved','2025-09-16 06:01:37',0.00),(61,150481212,'{\"price\": 30000, \"volume\": 10, \"duration\": 15, \"username\": \"tesssss01f\"}',30000,'expired','2025-09-16 18:46:31',0.00),(62,150481212,'{\"price\": 30000, \"volume\": 10, \"duration\": 17, \"username\": \"hhhsjsjss\"}',30000,'rejected','2025-09-16 19:46:33',0.00),(63,5877451098,'{\"price\": 35000, \"volume\": 14, \"duration\": 16, \"username\": \"hhhgccc\"}',35000,'rejected','2025-09-16 20:48:03',0.00),(64,150481212,'{\"volume\": 1, \"duration\": 1, \"username\": \"mo01\"}',1100,'rejected','2025-09-16 20:53:35',0.00),(65,150481212,'{\"volume\": 1, \"duration\": 1, \"username\": \"mo01\"}',1100,'approved','2025-09-16 20:55:12',0.00),(66,5877451098,'{\"volume\": 1, \"duration\": 1, \"username\": \"dortesst01\"}',1200,'approved','2025-09-17 07:51:36',0.00),(67,5877451098,'{\"type\": \"wallet_charge\", \"amount\": 120000}',120000,'approved','2025-09-18 05:22:26',0.00),(68,150481212,'{\"type\": \"wallet_charge\", \"amount\": 250000}',250000,'approved','2025-09-18 05:47:05',0.00),(69,150481212,'{\"price\": 30000, \"volume\": 10, \"duration\": 15, \"username\": \"mohtestw01\"}',30000,'approved','2025-09-18 05:49:48',0.00),(70,150481212,'{\"type\": \"wallet_charge\", \"amount\": 250000}',250000,'approved','2025-09-19 10:48:18',0.00),(71,99242966,'{\"type\": \"wallet_charge\", \"amount\": 65000}',65000,'approved','2025-09-19 10:53:53',0.00),(72,99242966,'{\"price\": 30000, \"volume\": 10, \"duration\": 15, \"username\": \"mohades03\"}',30000,'approved','2025-09-19 10:56:03',0.00),(73,76977825,'{\"volume\": 100, \"duration\": 31, \"username\": \"danial\"}',100000,'expired','2025-09-19 10:57:29',0.00),(74,76977825,'{\"volume\": 100, \"duration\": 31, \"username\": \"abolfazl\"}',110000,'expired','2025-09-19 12:09:06',0.00),(75,150481212,'{\"type\": \"wallet_charge\", \"amount\": 25000}',25000,'approved','2025-09-19 14:23:30',0.00),(76,76977825,'{\"volume\": 100, \"duration\": 31, \"username\": \"danial2\"}',100000,'expired','2025-09-19 23:18:34',0.00),(77,150481212,'{\"type\": \"wallet_charge\", \"amount\": 30000}',30000,'approved','2025-09-20 05:07:57',0.00),(78,150481212,'{\"price\": 35000, \"volume\": 10, \"duration\": 20, \"username\": \"mohtessd02\"}',35000,'expired','2025-09-20 05:09:18',0.00),(79,150481212,'{\"volume\": 1, \"duration\": 1, \"username\": \"mihtessstm02\"}',70000,'expired','2025-09-20 05:10:33',0.00),(80,150481212,'{\"price\": 140000, \"volume\": 999, \"max_ips\": 1, \"plan_id\": 2, \"duration\": 30, \"username\": \"jhzzhzjjz\", \"plan_type\": \"unlimited\"}',140000,'expired','2025-09-20 05:32:07',0.00),(81,150481212,'{\"type\": \"wallet_charge\", \"amount\": 70000}',70000,'expired','2025-09-20 05:33:08',0.00),(82,5877451098,'{\"type\": \"wallet_charge\", \"amount\": 25000}',25000,'approved','2025-09-20 08:34:24',0.00),(83,5877451098,'{\"price\": 35000, \"volume\": 12, \"duration\": 18, \"username\": \"dorstesst02\"}',35000,'approved','2025-09-20 08:35:55',0.00),(84,150481212,'{\"volume\": 10, \"duration\": 15, \"username\": \"mohtestw01\"}',30000,'approved','2025-09-21 13:49:27',0.00),(85,5604926986,'{\"volume\": 50, \"duration\": 30, \"username\": \"mohammad04\"}',80000,'expired','2025-09-21 13:53:29',0.00),(86,5604926986,'{\"volume\": 50, \"duration\": 30, \"username\": \"mohammad04\"}',80000,'expired','2025-09-21 13:53:32',0.00),(87,99242966,'{\"volume\": 10, \"duration\": 15, \"username\": \"mohades03\"}',30000,'expired','2025-09-21 13:54:36',0.00),(88,5604926986,'{\"volume\": 50, \"duration\": 30, \"username\": \"mohammad04\"}',80000,'expired','2025-09-21 13:55:58',0.00),(89,150481212,'{\"volume\": 40, \"duration\": 30, \"username\": \"mtesssst\"}',35000,'approved','2025-09-21 13:59:22',0.00),(90,150481212,'{\"type\": \"wallet_charge\", \"amount\": 150000}',150000,'approved','2025-09-21 14:06:54',0.00),(91,150481212,'{\"volume\": 50, \"duration\": 31, \"username\": \"mohammad04\"}',80000,'approved','2025-09-21 14:13:38',0.00),(92,150481212,'{\"volume\": 1, \"duration\": 1, \"username\": \"moh1230\"}',1200,'approved','2025-09-22 05:33:57',0.00),(93,150481212,'{\"price\": 30000, \"volume\": 10, \"duration\": 16, \"username\": \"moh1240\"}',30000,'expired','2025-09-22 05:35:58',0.00),(94,150481212,'{\"volume\": 1, \"duration\": 1, \"username\": \"mohtest02\"}',200,'expired','2025-09-22 05:43:14',0.00),(95,150481212,'{\"volume\": 2, \"duration\": 1, \"username\": \"mohtesss66\"}',6000,'expired','2025-09-22 06:19:39',0.00),(96,150481212,'{\"price\": 30000, \"volume\": 10, \"duration\": 17, \"username\": \"mohteesss8\"}',30000,'expired','2025-09-22 06:21:20',0.00),(97,5827504035,'{\"volume\": 40, \"duration\": 31, \"username\": \"hasan02\"}',80000,'approved','2025-09-22 08:59:02',0.00),(98,150481212,'{\"volume\": 3, \"duration\": 1, \"username\": \"mohtesss343\"}',3400,'expired','2025-09-22 09:23:50',0.00),(99,150481212,'{\"type\": \"wallet_charge\", \"amount\": 75000}',75000,'approved','2025-09-22 12:01:21',0.00),(100,99242966,'{\"volume\": 1, \"duration\": 1, \"username\": \"mohades33\"}',10000,'expired','2025-09-22 13:14:37',0.00),(101,150481212,'{\"volume\": 2, \"duration\": 2, \"username\": \"mohtessst003\"}',5200,'approved','2025-09-23 00:18:50',0.00),(102,150481212,'{\"volume\": 2, \"duration\": 5, \"username\": \"5rooz\"}',6700,'expired','2025-09-23 13:02:15',0.00),(103,150481212,'{\"volume\": 2, \"duration\": 5, \"username\": \"5rooz\"}',3210,'expired','2025-09-23 13:13:57',0.00),(104,1183805914,'{\"price\": 140000, \"volume\": 85, \"duration\": 60, \"username\": \"october\"}',140000,'expired','2025-09-23 20:57:02',0.00),(105,150481212,'{\"price\": 35000, \"volume\": 10, \"duration\": 20, \"username\": \"jjjjhhggg\"}',35000,'approved','2025-09-23 21:15:35',0.00),(106,150481212,'{\"price\": 140000, \"volume\": 999, \"max_ips\": 1, \"plan_id\": 2, \"duration\": 30, \"username\": \"mtesss\", \"plan_type\": \"unlimited\"}',140000,'approved','2025-09-23 21:21:12',0.00),(107,1183805914,'{\"price\": 140000, \"volume\": 85, \"duration\": 60, \"username\": \"october\"}',140000,'expired','2025-09-23 21:41:30',0.00),(108,150481212,'{\"price\": 140000, \"volume\": 85, \"duration\": 60, \"username\": \"nnnnnndd\"}',140000,'approved','2025-09-23 21:55:09',0.00),(109,76977825,'{\"volume\": 0, \"duration\": 31, \"username\": \"anahiita01\"}',100000,'expired','2025-09-24 01:24:35',0.00),(110,150481212,'{\"price\": 30000, \"volume\": 10, \"duration\": 15, \"username\": \"server01\"}',30000,'expired','2025-09-24 01:43:26',0.00),(111,150481212,'{\"volume\": 2, \"duration\": 5, \"username\": \"5rooz\"}',3210,'approved','2025-09-24 11:17:25',0.00),(112,150481212,'{\"volume\": 2, \"duration\": 5, \"username\": \"5rooz\"}',3210,'approved','2025-09-24 11:21:52',0.00),(113,150481212,'{\"price\": 85000, \"volume\": 50, \"duration\": 30, \"username\": \"delkhah01\"}',85000,'approved','2025-09-24 11:24:27',0.00),(114,150481212,'{\"volume\": 5, \"duration\": 6, \"username\": \"mers77\"}',5000,'approved','2025-09-24 11:25:59',0.00),(115,150481212,'{\"price\": 160000, \"volume\": 999, \"max_ips\": 2, \"plan_id\": 3, \"duration\": 30, \"username\": \"namahdd02\", \"plan_type\": \"unlimited\"}',160000,'approved','2025-09-24 11:31:24',0.00),(116,150481212,'{\"volume\": 0, \"duration\": 0, \"username\": \"mtestttt01\"}',4150,'expired','2025-09-24 14:32:02',0.00),(117,150481212,'{\"amount\": 25000, \"invoice_type\": \"WALLET_CHARGE\"}',25000,'approved','2025-09-24 16:42:03',0.00),(118,150481212,'{\"price\": 70000, \"volume\": 30, \"duration\": 30, \"username\": \"ntessss099\"}',70000,'approved','2025-09-24 16:43:19',0.00),(119,150481212,'{\"volume\": 1, \"duration\": 1, \"username\": \"nersss088\"}',59000,'approved','2025-09-24 16:44:46',0.00),(120,150481212,'{\"volume\": 1, \"duration\": 1, \"username\": \"nersss088\"}',59000,'expired','2025-09-24 16:47:09',0.00),(121,150481212,'{\"price\": 1350, \"volume\": 1, \"username\": \"nersss088\", \"plan_type\": \"data_top_up\"}',1350,'rejected','2025-09-24 16:48:40',0.00),(122,5877451098,'{\"price\": 30000, \"volume\": 10, \"duration\": 15, \"username\": \"dorsa2\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',30000,'approved','2025-09-24 20:30:29',0.00),(123,6557190169,'{\"volume\": 80, \"duration\": 100000, \"username\": \"9608639sara\", \"invoice_type\": \"RENEWAL\"}',100000,'expired','2025-09-24 20:33:33',0.00),(124,150481212,'{\"volume\": 30, \"duration\": 30, \"username\": \"ntessss099\", \"invoice_type\": \"RENEWAL\"}',70000,'approved','2025-09-24 20:47:03',0.00),(125,150481212,'{\"volume\": 30, \"duration\": 30, \"username\": \"ntessss099\", \"invoice_type\": \"RENEWAL\"}',70000,'approved','2025-09-24 20:47:29',0.00),(126,150481212,'{\"price\": 32000, \"volume\": 40, \"username\": \"ntessss099\", \"plan_type\": \"data_top_up\"}',32000,'rejected','2025-09-24 20:48:48',0.00),(127,150481212,'{\"amount\": 25000, \"invoice_type\": \"WALLET_CHARGE\"}',25000,'approved','2025-09-24 20:53:15',0.00),(128,150481212,'{\"price\": 85000, \"volume\": 30, \"duration\": 45, \"username\": \"feresh01\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',85000,'approved','2025-09-25 05:17:22',0.00),(129,150481212,'{\"price\": 50000, \"volume\": 30, \"duration\": 45, \"username\": \"feresh01\", \"invoice_type\": \"MANUAL_INVOICE\"}',50000,'approved','2025-09-25 05:22:14',0.00),(130,150481212,'{\"price\": 140000, \"volume\": 0, \"max_ips\": 1, \"plan_id\": 2, \"duration\": 30, \"username\": \"fershn01\", \"invoice_type\": \"NEW_USER_UNLIMITED\"}',140000,'approved','2025-09-25 06:03:58',0.00),(131,150481212,'{\"amount\": 25000, \"invoice_type\": \"WALLET_CHARGE\"}',25000,'approved','2025-09-25 08:51:50',0.00),(132,76977825,'{\"volume\": 100, \"duration\": 31, \"username\": \"parisa02\", \"invoice_type\": \"RENEWAL\"}',100000,'expired','2025-09-25 17:06:17',0.00),(133,99242966,'{\"amount\": 100000, \"invoice_type\": \"WALLET_CHARGE\"}',100000,'approved','2025-09-25 17:19:32',0.00),(134,76977825,'{\"volume\": 100, \"duration\": 31, \"username\": \"parisa02\", \"invoice_type\": \"RENEWAL\"}',100000,'expired','2025-09-26 08:53:39',0.00),(135,76977825,'{\"volume\": 100, \"duration\": 31, \"username\": \"parisa02\", \"invoice_type\": \"RENEWAL\"}',100000,'expired','2025-09-26 09:02:26',0.00),(136,76977825,'{\"volume\": 100, \"duration\": 31, \"username\": \"parisa02\", \"invoice_type\": \"RENEWAL\"}',100000,'expired','2025-09-26 09:03:31',0.00),(137,76977825,'{\"volume\": 100, \"duration\": 31, \"username\": \"parisa02\", \"invoice_type\": \"RENEWAL\"}',100000,'expired','2025-09-26 09:04:35',0.00),(138,150481212,'{\"volume\": 0, \"duration\": 30, \"username\": \"fershn01\", \"invoice_type\": \"RENEWAL\"}',140000,'expired','2025-09-26 09:08:26',0.00),(139,76977825,'{\"volume\": 100, \"duration\": 31, \"username\": \"parisa02\", \"invoice_type\": \"RENEWAL\"}',100000,'expired','2025-09-26 09:10:03',0.00),(140,76977825,'{\"volume\": 100, \"duration\": 31, \"username\": \"parisa02\", \"invoice_type\": \"RENEWAL\"}',100000,'approved','2025-09-26 09:10:59',0.00),(141,150481212,'{\"volume\": 0, \"duration\": 30, \"username\": \"fershn01\", \"invoice_type\": \"RENEWAL\"}',140000,'expired','2025-09-26 09:12:35',0.00),(142,76977825,'{\"price\": 55000, \"volume\": 20, \"duration\": 30, \"username\": \"mehdi\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',55000,'approved','2025-09-26 09:16:46',0.00),(143,76977825,'{\"amount\": 200000, \"invoice_type\": \"WALLET_CHARGE\"}',200000,'approved','2025-09-26 09:19:22',0.00),(144,150481212,'{\"volume\": 0, \"duration\": 30, \"username\": \"fershn01\", \"invoice_type\": \"RENEWAL\"}',140000,'approved','2025-09-26 09:24:08',0.00),(145,76977825,'{\"volume\": 20, \"duration\": 30, \"username\": \"mehdi\", \"invoice_type\": \"RENEWAL\"}',55000,'expired','2025-09-26 09:24:09',0.00),(146,76977825,'{\"volume\": 20, \"duration\": 30, \"username\": \"mehdi\", \"invoice_type\": \"RENEWAL\"}',55000,'approved','2025-09-26 09:25:30',0.00),(147,76977825,'{\"amount\": 200000, \"invoice_type\": \"WALLET_CHARGE\"}',200000,'approved','2025-09-26 09:27:48',0.00),(148,99242966,'{\"volume\": 20, \"duration\": 30, \"username\": \"mohadeseh\", \"invoice_type\": \"RENEWAL\"}',70000,'expired','2025-09-26 09:41:21',0.00),(149,99242966,'{\"volume\": 20, \"duration\": 30, \"username\": \"mohadeseh\", \"invoice_type\": \"RENEWAL\"}',70000,'approved','2025-09-26 09:41:47',0.00),(150,99242966,'{\"price\": 30000, \"volume\": 10, \"duration\": 15, \"username\": \"mohades02\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',30000,'approved','2025-09-26 09:45:27',0.00),(151,99242966,'{\"price\": 35000, \"volume\": 10, \"duration\": 20, \"username\": \"jhhghhh\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',35000,'approved','2025-09-26 09:47:54',0.00),(152,150481212,'{\"volume\": 0, \"duration\": 30, \"username\": \"fershn01\", \"invoice_type\": \"RENEWAL\"}',140000,'approved','2025-09-26 12:42:27',0.00),(153,150481212,'{\"price\": 58000, \"volume\": 2, \"duration\": 2, \"username\": \"mtesssd7\", \"invoice_type\": \"MANUAL_INVOICE\"}',58000,'approved','2025-09-26 12:46:31',0.00),(154,150481212,'{\"price\": 140000, \"volume\": 0, \"max_ips\": 1, \"plan_id\": 2, \"duration\": 30, \"username\": \"mteeessaa8\", \"invoice_type\": \"NEW_USER_UNLIMITED\"}',140000,'approved','2025-09-26 13:16:52',0.00),(155,150481212,'{\"amount\": 200000, \"invoice_type\": \"WALLET_CHARGE\"}',200000,'approved','2025-09-26 13:17:28',0.00),(156,150481212,'{\"price\": 140000, \"volume\": 0, \"max_ips\": 1, \"plan_id\": 2, \"duration\": 30, \"username\": \"mtessss4\", \"invoice_type\": \"NEW_USER_UNLIMITED\"}',140000,'approved','2025-09-26 13:18:22',0.00),(157,150481212,'{\"price\": 27000, \"volume\": 45, \"username\": \"fershn01\", \"plan_type\": \"data_top_up\", \"invoice_type\": \"DATA_TOP_UP\"}',27000,'expired','2025-09-26 16:10:48',0.00),(158,150481212,'{\"volume\": 2, \"duration\": 2, \"username\": \"mtesssd7\", \"invoice_type\": \"RENEWAL\"}',58000,'approved','2025-09-27 10:56:05',0.00),(159,99242966,'{\"volume\": 20, \"duration\": 30, \"username\": \"mohadeseh\", \"invoice_type\": \"RENEWAL\"}',70000,'expired','2025-09-27 11:10:09',0.00),(160,100912247,'{\"volume\": 150, \"duration\": 90, \"username\": \"farnaz\", \"invoice_type\": \"RENEWAL\"}',100,'approved','2025-09-27 17:29:45',0.00),(161,7913968242,'{\"volume\": 80, \"duration\": 31, \"username\": \"mim\", \"invoice_type\": \"RENEWAL\"}',100000,'expired','2025-09-28 10:44:35',0.00),(162,6144847019,'{\"volume\": 40, \"duration\": 30, \"username\": \"mehrdad\", \"invoice_type\": \"RENEWAL\"}',80000,'expired','2025-09-28 13:00:46',0.00),(163,150481212,'{\"price\": 41000, \"volume\": 0, \"duration\": 0, \"username\": \"fastvpn\", \"invoice_type\": \"MANUAL_INVOICE\"}',41000,'expired','2025-09-29 02:32:47',0.00),(164,150481212,'{\"price\": 2000, \"volume\": 0, \"duration\": 0, \"username\": \"fastvpn\", \"invoice_type\": \"MANUAL_INVOICE\"}',2000,'expired','2025-09-29 02:33:38',0.00),(165,150481212,'{\"volume\": 20, \"duration\": 30, \"username\": \"fastvpn\", \"invoice_type\": \"RENEWAL\"}',35000,'expired','2025-09-29 03:13:32',0.00),(166,150481212,'{\"price\": 5001, \"volume\": 20, \"duration\": 30, \"username\": \"fastvpn\", \"invoice_type\": \"MANUAL_INVOICE\"}',5001,'expired','2025-09-29 03:14:14',0.00),(167,150481212,'{\"price\": 35000, \"volume\": 10, \"duration\": 20, \"username\": \"mdel00002\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',35000,'approved','2025-09-29 03:15:11',0.00),(168,150481212,'{\"price\": 185000, \"volume\": 120, \"duration\": 90, \"username\": \"hhghhhd\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',185000,'expired','2025-09-29 14:03:04',0.00),(169,150481212,'{\"price\": 155000, \"volume\": 120, \"duration\": 60, \"username\": \"wallet02\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',155000,'approved','2025-09-30 03:27:23',0.00),(170,150481212,'{\"amount\": 75000, \"invoice_type\": \"WALLET_CHARGE\"}',75000,'approved','2025-09-30 03:31:33',0.00),(171,150481212,'{\"price\": 13500, \"volume\": 10, \"username\": \"wallet02\", \"plan_type\": \"data_top_up\", \"invoice_type\": \"DATA_TOP_UP\"}',13500,'approved','2025-09-30 03:33:15',0.00),(172,150481212,'{\"volume\": 120, \"duration\": 60, \"username\": \"wallet02\", \"invoice_type\": \"RENEWAL\"}',155000,'approved','2025-09-30 03:34:17',0.00),(173,150481212,'{\"amount\": 50000, \"invoice_type\": \"WALLET_CHARGE\"}',50000,'approved','2025-09-30 06:30:22',0.00),(174,150481212,'{\"volume\": 10, \"duration\": 20, \"username\": \"mdel00002\", \"invoice_type\": \"RENEWAL\"}',35000,'approved','2025-09-30 06:36:01',0.00),(175,99242966,'{\"price\": 30000, \"volume\": 10, \"duration\": 15, \"username\": \"mohades02\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',30000,'approved','2025-10-01 04:59:03',0.00),(176,90111767,'{\"volume\": 0, \"duration\": 31, \"username\": \"aliasghar\", \"invoice_type\": \"RENEWAL\"}',160000,'expired','2025-10-01 10:57:59',0.00),(177,5827504035,'{\"volume\": 40, \"duration\": 30, \"username\": \"keshavarz\", \"invoice_type\": \"RENEWAL\"}',80000,'approved','2025-10-01 11:26:14',0.00),(178,5877451098,'{\"amount\": 50000, \"invoice_type\": \"WALLET_CHARGE\"}',50000,'approved','2025-10-01 17:56:38',0.00),(179,5877451098,'{\"price\": 30000, \"volume\": 10, \"duration\": 15, \"username\": \"admintesst\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',30000,'approved','2025-10-01 17:58:42',0.00),(180,5877451098,'{\"amount\": 50000, \"invoice_type\": \"WALLET_CHARGE\"}',50000,'approved','2025-10-01 18:28:18',0.00),(181,150481212,'{\"price\": 4500, \"volume\": 1, \"duration\": 1, \"username\": \"mohtesst\", \"invoice_type\": \"MANUAL_INVOICE\"}',4500,'approved','2025-10-01 18:30:48',0.00),(182,150481212,'{\"amount\": 50000, \"invoice_type\": \"WALLET_CHARGE\"}',50000,'approved','2025-10-01 18:32:47',0.00),(183,150481212,'{\"price\": 4500.0, \"volume\": 1.0, \"duration\": 1, \"username\": \"mohtesst\", \"invoice_type\": \"RENEWAL\"}',4500,'approved','2025-10-01 18:35:01',0.00),(184,150481212,'{\"volume\": 1, \"duration\": 1, \"username\": \"mohtesst\", \"invoice_type\": \"RENEWAL\"}',4500,'approved','2025-10-02 04:54:18',0.00),(185,150481212,'{\"price\": 4500.0, \"volume\": 1.0, \"duration\": 1, \"username\": \"mohtesst\", \"invoice_type\": \"RENEWAL\"}',4500,'approved','2025-10-02 18:35:01',0.00),(186,150481212,'{\"price\": 30000, \"volume\": 10, \"duration\": 15, \"username\": \"feres02\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',30000,'approved','2025-10-03 03:59:25',0.00),(187,90111767,'{\"volume\": 0, \"duration\": 31, \"username\": \"aliasghar\", \"invoice_type\": \"RENEWAL\"}',160000,'approved','2025-10-03 05:52:12',0.00),(188,150481212,'{\"price\": 25000, \"volume\": 1, \"duration\": 10, \"username\": \"moh1122\", \"invoice_type\": \"MANUAL_INVOICE\"}',25000,'approved','2025-10-03 12:59:30',0.00),(189,150481212,'{\"volume\": 1, \"duration\": 10, \"username\": \"moh1122\", \"invoice_type\": \"RENEWAL\"}',25000,'approved','2025-10-03 13:05:37',0.00),(190,150481212,'{\"price\": 30000, \"volume\": 10, \"duration\": 15, \"username\": \"tessst42\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',30000,'approved','2025-10-05 06:38:46',0.00),(191,150481212,'{\"volume\": 1, \"duration\": 10, \"username\": \"moh1122\", \"invoice_type\": \"RENEWAL\"}',25000,'approved','2025-10-05 16:22:11',0.00),(192,150481212,'{\"volume\": 1, \"duration\": 10, \"username\": \"moh1122\", \"invoice_type\": \"RENEWAL\"}',25000,'approved','2025-10-06 16:27:09',0.00),(193,8042154671,'{\"price\": 110000, \"volume\": 50, \"duration\": 60, \"username\": \"rezasartipi\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',110000,'expired','2025-10-06 20:10:26',0.00),(194,5877451098,'{\"amount\": 10000, \"invoice_type\": \"WALLET_CHARGE\"}',10000,'approved','2025-10-06 22:20:00',0.00),(195,1183805914,'{\"price\": 30000, \"volume\": 10, \"duration\": 15, \"username\": \"arvin\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',30000,'expired','2025-10-07 14:04:07',0.00),(196,1183805914,'{\"price\": 30000, \"volume\": 10, \"duration\": 15, \"username\": \"arvin\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',30000,'expired','2025-10-07 14:05:45',0.00),(197,5569979117,'{\"price\": 30000, \"volume\": 10, \"duration\": 15, \"username\": \"leila65\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',30000,'approved','2025-10-09 08:51:44',0.00),(198,150481212,'{\"price\": 35000, \"volume\": 10, \"duration\": 20, \"username\": \"dtesst8\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',35000,'approved','2025-10-09 17:14:00',0.00),(199,150481212,'{\"amount\": 30000, \"invoice_type\": \"WALLET_CHARGE\"}',30000,'rejected','2025-10-09 22:53:54',0.00),(200,551043378,'{\"price\": 50000, \"volume\": 15, \"duration\": 30, \"username\": \"ashe1\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',50000,'approved','2025-10-10 16:45:54',0.00),(201,7606035924,'{\"volume\": 200, \"duration\": 90, \"username\": \"parisa\", \"invoice_type\": \"RENEWAL\"}',1000,'approved','2025-10-11 06:55:38',0.00),(202,7606035924,'{\"volume\": 200, \"duration\": 90, \"username\": \"parisa\", \"invoice_type\": \"RENEWAL\"}',1000,'approved','2025-10-11 08:24:18',0.00),(203,150481212,'{\"volume\": 10, \"duration\": 20, \"username\": \"dtesst8\", \"invoice_type\": \"RENEWAL\"}',35000,'expired','2025-10-12 01:51:26',0.00),(204,150481212,'{\"price\": 45000, \"volume\": 10, \"duration\": 30, \"username\": \"mtessssqq9\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',45000,'expired','2025-10-12 16:18:19',0.00),(205,150481212,'{\"amount\": 200000, \"invoice_type\": \"WALLET_CHARGE\"}',200000,'approved','2025-10-13 16:29:19',0.00),(206,150481212,'{\"price\": 35000, \"volume\": 10, \"duration\": 20, \"username\": \"tessst02\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',35000,'approved','2025-10-13 16:53:43',35000.00),(207,150481212,'{\"type\": \"data_top_up\", \"price\": 30000, \"volume\": 50, \"duration\": \"حجم اضافه\", \"username\": \"tessst02\", \"plan_type\": \"data_top_up\", \"invoice_type\": \"DATA_TOP_UP\"}',30000,'approved','2025-10-13 17:03:08',30000.00),(208,150481212,'{\"price\": 3100, \"username\": \"tessssty7\", \"invoice_type\": \"RENEWAL\"}',3100,'expired','2025-10-13 23:54:55',0.00),(209,150481212,'{\"price\": 3100, \"username\": \"tessssty7\", \"invoice_type\": \"RENEWAL\"}',3100,'expired','2025-10-14 00:23:43',0.00),(210,150481212,'{\"price\": 35000, \"username\": \"tessst02\", \"invoice_type\": \"RENEWAL\"}',35000,'expired','2025-10-14 02:14:11',0.00),(211,150481212,'{\"price\": 34000, \"volume\": 2, \"duration\": 1, \"username\": \"mtt1212\", \"invoice_type\": \"MANUAL_INVOICE\"}',34000,'approved','2025-10-14 09:53:34',0.00),(212,150481212,'{\"price\": 45000, \"volume\": 10, \"duration\": 30, \"username\": \"dddd1212\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',45000,'approved','2025-10-14 09:56:10',30000.00),(213,150481212,'{\"price\": 140000, \"volume\": 0, \"max_ips\": 1, \"plan_id\": 2, \"duration\": 30, \"username\": \"na1212\", \"plan_name\": \"💎 اشتراک نامحدود یک ماهه  تک کاربره👤\", \"invoice_type\": \"NEW_USER_UNLIMITED\"}',140000,'approved','2025-10-14 09:57:29',0.00),(214,150481212,'{\"amount\": 50000, \"invoice_type\": \"WALLET_CHARGE\"}',50000,'approved','2025-10-14 09:59:22',0.00),(215,150481212,'{\"price\": 25000, \"volume\": 2, \"duration\": 2, \"username\": \"mdo1212\", \"invoice_type\": \"MANUAL_INVOICE\"}',25000,'approved','2025-10-14 10:00:49',0.00),(216,150481212,'{\"price\": 15000, \"volume\": 2, \"duration\": 1, \"username\": \"mtt1212\", \"invoice_type\": \"MANUAL_INVOICE\"}',15000,'approved','2025-10-14 10:14:40',0.00),(217,150481212,'{\"type\": \"data_top_up\", \"price\": 30000, \"volume\": 50, \"duration\": \"حجم اضافه\", \"username\": \"dddd1212\", \"plan_type\": \"data_top_up\", \"invoice_type\": \"DATA_TOP_UP\"}',30000,'approved','2025-10-14 10:19:27',30000.00),(218,5877451098,'{\"price\": 35000, \"volume\": 10, \"duration\": 20, \"username\": \"ttteee\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',35000,'expired','2025-10-14 16:11:40',35000.00),(219,150481212,'{\"price\": 30000, \"volume\": 10, \"duration\": 15, \"username\": \"mntttt02\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',30000,'approved','2025-10-14 16:21:26',20000.00),(220,150481212,'{\"price\": 4300, \"volume\": 1, \"duration\": 1, \"username\": \"poshtttttt02\", \"invoice_type\": \"MANUAL_INVOICE\"}',4300,'approved','2025-10-14 16:23:42',0.00),(221,150481212,'{\"price\": 4300, \"volume\": 1, \"duration\": 1, \"username\": \"poshtttttt02\", \"invoice_type\": \"RENEWAL\"}',4300,'approved','2025-10-14 16:36:39',0.00),(222,150481212,'{\"price\": 140000, \"volume\": 0, \"duration\": 30, \"username\": \"na1212\", \"invoice_type\": \"RENEWAL\"}',140000,'expired','2025-10-15 21:38:43',0.00),(223,150481212,'{\"price\": 130000, \"volume\": 80, \"duration\": 60, \"username\": \"hhgahsh\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',130000,'approved','2025-10-16 08:51:58',0.00),(224,6548323566,'{\"price\": 1000, \"volume\": 150, \"duration\": 90, \"username\": \"amirali\", \"invoice_type\": \"RENEWAL\"}',1000,'expired','2025-10-16 21:27:07',0.00),(225,6548323566,'{\"price\": 1000, \"volume\": 150, \"duration\": 90, \"username\": \"amirali\", \"invoice_type\": \"RENEWAL\"}',1000,'expired','2025-10-17 16:42:53',0.00),(226,6548323566,'{\"price\": 1000, \"volume\": 150, \"duration\": 90, \"username\": \"amirali\", \"invoice_type\": \"RENEWAL\"}',1000,'expired','2025-10-17 16:44:05',0.00),(227,5877451098,'{\"price\": 80000, \"volume\": 30, \"duration\": 30, \"username\": \"dorsa\", \"invoice_type\": \"RENEWAL\"}',80000,'expired','2025-10-17 17:01:58',0.00),(228,5877451098,'{\"price\": 4300, \"volume\": 1, \"duration\": 1, \"username\": \"gfggf\", \"invoice_type\": \"MANUAL_INVOICE\"}',4300,'approved','2025-10-18 08:47:32',0.00),(229,150481212,'{\"price\": 6700, \"volume\": 1, \"duration\": 1, \"username\": \"ytyyyyy\", \"invoice_type\": \"MANUAL_INVOICE\"}',6700,'expired','2025-10-18 08:49:42',0.00),(230,150481212,'{\"price\": 30000, \"volume\": 10, \"duration\": 15, \"username\": \"testrooz\", \"invoice_type\": \"NEW_USER_CUSTOM\"}',30000,'approved','2025-10-19 14:16:24',30000.00),(231,76977825,'{\"price\": 110000, \"volume\": 100, \"duration\": 31, \"username\": \"abolfazl\", \"invoice_type\": \"RENEWAL\"}',110000,'approved','2025-10-20 15:47:05',0.00),(232,76977825,'{\"amount\": 500000, \"invoice_type\": \"WALLET_CHARGE\"}',500000,'approved','2025-10-20 15:52:26',0.00),(233,150481212,'{\"amount\": 50000, \"invoice_type\": \"WALLET_CHARGE\"}',50000,'approved','2025-10-20 16:03:18',0.00),(234,150481212,'{\"amount\": 100000, \"invoice_type\": \"WALLET_CHARGE\"}',100000,'approved','2025-10-20 16:04:13',0.00),(235,150481212,'{\"amount\": 25000, \"invoice_type\": \"WALLET_CHARGE\"}',25000,'approved','2025-10-21 03:40:55',0.00),(236,76977825,'{\"price\": 160000, \"volume\": 0, \"max_ips\": 2, \"plan_id\": 3, \"duration\": 30, \"username\": \"mohsen02\", \"plan_name\": \"اشتراک نامحدود  یک ماه دو کاربره 👥️\", \"invoice_type\": \"NEW_USER_UNLIMITED\"}',160000,'approved','2025-10-21 13:19:44',160000.00),(237,5604926986,'{\"price\": 80000, \"volume\": 50, \"duration\": 31, \"username\": \"mohammad04\", \"invoice_type\": \"MANUAL_INVOICE\"}',80000,'expired','2025-10-21 14:53:29',0.00),(238,76977825,'{\"price\": 100000, \"volume\": 100, \"duration\": 31, \"username\": \"danial2\", \"invoice_type\": \"RENEWAL\"}',100000,'approved','2025-10-21 20:50:45',0.00),(239,76977825,'{\"price\": 100000, \"volume\": 100, \"duration\": 31, \"username\": \"danial\", \"invoice_type\": \"RENEWAL\"}',100000,'approved','2025-10-21 20:50:51',0.00),(240,76977825,'{\"price\": 100000, \"volume\": 100, \"duration\": 31, \"username\": \"danial\", \"invoice_type\": \"RENEWAL\"}',100000,'expired','2025-10-21 20:51:57',0.00),(241,76977825,'{\"price\": 100000.0, \"volume\": 100.0, \"duration\": 30, \"username\": \"ashkan02\", \"invoice_type\": \"RENEWAL\"}',100000,'approved','2025-10-22 05:36:01',0.00);
/*!40000 ALTER TABLE `pending_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template_config`
--

DROP TABLE IF EXISTS `template_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `template_config` (
  `id` int NOT NULL DEFAULT '1',
  `template_username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `proxies` json DEFAULT NULL,
  `inbounds` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_config`
--

LOCK TABLES `template_config` WRITE;
/*!40000 ALTER TABLE `template_config` DISABLE KEYS */;
INSERT INTO `template_config` VALUES (1,'dorsa','{\"vless\": {\"id\": \"7408d323-9ee4-4dc2-bf0f-5c37645efcff\", \"flow\": \"\"}}','{\"vless\": [\"VLESS XHTTP REALITY franc2\", \"VLESS-XHTTP-NOTLS fastlly sw\", \"VLESS-XHTTP-NOTLS fastlly far\", \"VLESS WS TLS  fra\", \"VLESS + GRPC + REALITY-ip4-nod-bot\", \"VLESS TCP TLS\", \"VLESS XHTTP REALITY franc\", \"VLESS XHTTP REALITY us\"]}');
/*!40000 ALTER TABLE `template_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unlimited_plans`
--

DROP TABLE IF EXISTS `unlimited_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unlimited_plans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `plan_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int NOT NULL,
  `max_ips` int NOT NULL DEFAULT '1',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unlimited_plans`
--

LOCK TABLES `unlimited_plans` WRITE;
/*!40000 ALTER TABLE `unlimited_plans` DISABLE KEYS */;
INSERT INTO `unlimited_plans` VALUES (2,'💎 اشتراک نامحدود یک ماهه  تک کاربره👤',140000,1,1,1),(3,'اشتراک نامحدود  یک ماه دو کاربره 👥️',160000,2,1,2);
/*!40000 ALTER TABLE `unlimited_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_notes`
--

DROP TABLE IF EXISTS `user_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_notes` (
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `subscription_duration` int DEFAULT NULL,
  `subscription_data_limit_gb` int DEFAULT NULL,
  `subscription_price` int DEFAULT NULL,
  `is_test_account` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_notes`
--

LOCK TABLES `user_notes` WRITE;
/*!40000 ALTER TABLE `user_notes` DISABLE KEYS */;
INSERT INTO `user_notes` VALUES ('5rooz',NULL,5,2,3210,0),('9608639sara',NULL,100000,80,100000,0),('abolfazl',NULL,31,100,110000,0),('ali01',NULL,90,300,300000,0),('aliasghar',NULL,31,0,160000,0),('amirali',NULL,90,150,1000,0),('anahiita01',NULL,31,0,100000,0),('ashe1',NULL,30,15,50000,0),('ashkan02',NULL,30,100,100000,0),('danial',NULL,31,100,100000,0),('danial2',NULL,31,100,100000,0),('davoud',NULL,91,0,320000,0),('delkhah01',NULL,30,50,85000,0),('dorsa',NULL,30,30,80000,0),('dorsa2',NULL,15,10,30000,0),('dorstesst02',NULL,18,12,35000,0),('douvood',NULL,31,100,100000,0),('dtesst8',NULL,20,10,35000,0),('esmaeil',NULL,30,40,80000,0),('farnaz',NULL,90,150,100,0),('farzad',NULL,30,40,80000,0),('fastvpn',NULL,30,20,35000,0),('feres02',NULL,15,10,30000,0),('feresh01',NULL,45,30,50000,0),('fershn01',NULL,30,0,140000,0),('ganan',NULL,91,200,300000,0),('gdfdf',NULL,2,3,5330,0),('haniyeh',NULL,90,200,1000,0),('hasan02',NULL,31,40,80000,0),('hhgahsh',NULL,60,80,130000,0),('hosein10',NULL,30,70,0,0),('kam',NULL,30,30,20000,0),('keshavarz',NULL,30,40,80000,0),('khoodadad02',NULL,31,100,100000,0),('leila65',NULL,15,10,30000,0),('lortabaran',NULL,30,100,100000,0),('mahdi02',NULL,90,200,1000,0),('mamad-ana2',NULL,30,60,0,0),('mees02',NULL,2,1,0,0),('mees8',NULL,4,3,0,0),('mehdi',NULL,30,20,55000,0),('mehrdad',NULL,30,40,80000,0),('mers02nn',NULL,30,10,50000,0),('mers3m',NULL,90,0,0,0),('mers77',NULL,6,5,0,0),('mihtessstm02',NULL,1,1,0,0),('mim',NULL,31,80,100000,0),('mmm05',NULL,2,2,0,0),('mmmmo07',NULL,2,1,0,0),('moh01',NULL,1,1,0,0),('moh02',NULL,2,NULL,0,0),('moh03',NULL,5,4,2001,0),('moh04',NULL,1,1,0,0),('moh1122',NULL,10,1,25000,0),('mohades02',NULL,15,10,30000,0),('mohades03',NULL,15,10,30000,0),('mohades33',NULL,1,1,0,0),('mohadeseh',NULL,30,20,70000,0),('mohammad04',NULL,31,50,80000,0),('mohatesal0223',NULL,1,1,2100,0),('mohsen02',NULL,30,0,160000,0),('mohtesss343',NULL,1,3,0,0),('mohtesss66',NULL,1,2,0,0),('mohtessst003',NULL,2,2,0,0),('mohtesst',NULL,1,1,4500,0),('mohtest02',NULL,1,1,200,0),('morteza02',NULL,31,100,100000,0),('mteeessaa8',NULL,30,0,140000,0),('mtesssd7',NULL,2,2,58000,0),('mtessss4',NULL,30,0,140000,0),('mtesssst',NULL,NULL,NULL,NULL,0),('namahdd02',NULL,30,0,160000,0),('narges03',NULL,31,100,100000,0),('navid02',NULL,60,85,140000,0),('nersss088',NULL,1,1,59000,0),('nnnnnndd',NULL,60,85,140000,0),('ntessss099',NULL,30,30,70000,0),('parisa',NULL,90,200,1000,0),('parisa02',NULL,31,100,100000,0),('poshtttttt02',NULL,1,1,4300,0),('sajad',NULL,90,0,300000,0),('tessssty7',NULL,2,2,3100,0),('tessst02',NULL,20,10,35000,0),('tessst42',NULL,15,10,30000,0),('test_5877451098_a5w4',NULL,0,0,0,0),('test_5877451098_nyrj',NULL,0,0,0,0),('test_5877451098_yidy',NULL,0,0,0,0),('tizhoosh',NULL,31,80,0,0),('ttteee',NULL,20,10,35000,0);
/*!40000 ALTER TABLE `user_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` bigint NOT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT '0',
  `join_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `wallet_balance` decimal(15,2) NOT NULL DEFAULT '0.00',
  `test_accounts_received` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (76977825,'@Mama2211Ma','Mama2211',0,'2025-08-19 09:51:10',275000.00,0),(90111767,'Ali asghar',NULL,0,'2025-09-01 22:05:56',0.00,0),(99133957,'Khadijeh','Khadij611001',0,'2025-10-15 06:35:07',30000.00,1),(99242966,'✨ 𝓜𝓸𝓱𝓪𝓭𝓮𝓼𝓮𝓱','mohadesehh92',0,'2025-08-21 05:23:22',45000.00,2),(100616027,'محمد','Reza58921',0,'2025-10-16 02:27:15',30000.00,0),(100912247,'Farahnaz','Farahnaz1359',0,'2025-09-27 17:29:37',0.00,0),(110638952,'kazem','kzmhs',0,'2025-10-03 16:31:20',30000.00,0),(150481212,'Σohammad','mohammad6689',0,'2025-10-16 13:59:35',175000.00,8),(551043378,'ali','ashewrld',0,'2025-10-10 16:43:36',30000.00,0),(568798318,'Armin','Armin_Ghadri',0,'2025-10-01 08:19:38',0.00,1),(911285172,'M_K','Moisabll',0,'2025-10-16 12:45:57',30000.00,2),(954038397,'Auto spark','alihamraei',0,'2025-10-15 09:13:16',30000.00,0),(1183805914,'𝗔𝗥𝗩𝗜𝗡','arvinhassanzadeh',0,'2025-09-23 20:50:19',0.00,0),(2099749524,'A',NULL,0,'2025-10-23 10:25:37',30000.00,0),(5569979117,'لیلا',NULL,0,'2025-10-03 16:29:30',0.00,0),(5604926986,'محمد',NULL,0,'2025-08-21 00:56:27',0.00,0),(5827504035,'ممد ًانی',NULL,0,'2025-08-19 17:31:42',0.00,0),(5877451098,'mers','mers_vpn',0,'2025-08-18 10:02:40',60000.00,17),(6144847019,'M',NULL,0,'2025-09-28 10:50:27',0.00,0),(6191287529,'A','abdanan121',0,'2025-08-31 14:28:18',0.00,0),(6233097509,'khodadad','khodadad1122',0,'2025-08-20 09:17:58',0.00,0),(6548323566,'امیر','amirr150',0,'2025-08-22 09:51:25',0.00,0),(6557190169,'🦂𝐒𝐚𝐫𝐚🦂',NULL,0,'2025-08-22 09:25:40',0.00,0),(6680925972,'مهرسام','mehrsamm95',0,'2025-08-18 11:47:44',0.00,0),(7606035924,'Parissa','Pari_0505',0,'2025-08-26 06:41:49',9000.00,0),(7693795045,'نرگس',NULL,0,'2025-10-22 10:05:35',30000.00,0),(7913968242,'Mmd','mmd0_107',0,'2025-08-27 15:27:00',0.00,0),(8042154671,'reza',NULL,0,'2025-10-06 20:08:18',30000.00,0),(8172420461,'لرتباران','lortabaranofficial',0,'2025-09-14 03:02:21',0.00,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumetric_pricing_tiers`
--

DROP TABLE IF EXISTS `volumetric_pricing_tiers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumetric_pricing_tiers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tier_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `volume_limit_gb` int NOT NULL,
  `price_per_gb` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `volume_limit_gb` (`volume_limit_gb`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumetric_pricing_tiers`
--

LOCK TABLES `volumetric_pricing_tiers` WRITE;
/*!40000 ALTER TABLE `volumetric_pricing_tiers` DISABLE KEYS */;
INSERT INTO `volumetric_pricing_tiers` VALUES (1,'پلن پایه',30,1350),(2,'پلن متوسط',60,600),(3,'پلن پیشرفته',90,650),(4,'پلن حرفه‌ای',120,600);
/*!40000 ALTER TABLE `volumetric_pricing_tiers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-24  0:00:02
